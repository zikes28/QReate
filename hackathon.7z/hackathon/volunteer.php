<?php
$conn = new mysqli("127.0.0.1", "root", "", "FeedingSouthFlorida");
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$firstName = $_POST['firstName'];
$lastName = $_POST['lastName'];
$email = $_POST['email'];
$jobID = $_POST['jobID'];
$sql = "INSERT INTO volunteers (FName, LName, Email, Job_ID) VALUES ('$firstName', '$lastName', '$email', '$jobID')";
if ($conn->query($sql) === TRUE) {
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
$sql = "UPDATE jobs SET Job_Limit_Status=Job_Limit_Status + 1 WHERE Job_ID=$jobID";
if ($conn->query($sql) === TRUE) {
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}






?>
