
<html>
<link rel="stylesheet" href="update2.css">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
<script src="code5.js"></script>
<form action='volunteer.php' method='post' id='volunteerForm'>
<br><div class="event">SignIn:</div>
<div class='title'>First Name:</div>
<input class='box' type='text' name="firstName" id="firstName">
<div class='title'>Last Name:</div>
<input class='box' type='text' name="lastName" id="lastName">
<div class='title'>Email:</div>
<input class='box' type="email" name="email" id="email">
<br><br><div class="event">Pick a Job:</div>
<?php
$conn = new mysqli("127.0.0.1", "root", "", "FeedingSouthFlorida");
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
if (isset($_GET['event'])){
  $event = $_GET['event'];
  $sql = "SELECT Job_ID, Job_Name, Job_Desc, Job_Limit, Job_Limit_Status, Event_ID FROM jobs WHERE Event_ID='$event'";
  $result = $conn->query($sql);
  if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      if($row["Job_Limit_Status"] >= $row["Job_Limit"]){
      } else{
        echo "<div class='jobTitle'>".$row["Job_Name"]."</div><div class='jobDesc'>".$row["Job_Limit_Status"]."/".$row["Job_Limit"]."</div><div class='jobDesc'>".$row["Job_Desc"]."</div><button type='button' class='buttonText' onclick='areYouSure(".$row["Job_ID"].")'>Select</button></div>";
      }
    }
  } else {
    echo "Event does not have jobs assigned or does not exist.";
  }
  $sql = "SELECT Overlay_Message FROM vevents WHERE Event_ID='$event'";
  $result = $conn->query($sql);
  if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      $overlayMessage = $row["Overlay_Message"];
      echo("<div class='overlay' id='overlay'><div class='title'>Preliminary Message:</div><div class='overlayText' id='overlayText'>".$overlayMessage."</div><button class='overlayButton' type='button' onclick='hideOverlay()'>Hide Overlay</button></div>");
    }
  }
}
else{
  echo("no event specified");
}
$conn->close();
?>
</form>
</html>
