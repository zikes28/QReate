<?php
$username = $_POST['username'];
$password = $_POST['password']




//Connection key
$conn = new mysqli("127.0.0.1", "root", "", "FeedingSouthFlorida");
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}

//dbx_query
$result = mysql_query("select* from users where username = '$username' and password = '$password'") or
die("Failed to quesry the db". mysql_error());

$row = mysql_fetch_array($result);
  if ($row['username'] == $username && $row['password'] == $password){
    echo "Welcome " . $row['username'];
  } else {
    echo ("Login Failed");
  }
?>
