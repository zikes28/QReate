<html>
<link rel="stylesheet" href="update2.css">
  <script src="code5.js"></script>
  <script src="qrcode.min.js"></script>
  <form method="post" action="insert.php" class="form">
    <div class="event">Event Creation</div><br>
    <div class="title">Event Name:</div>
      <div class="input">
        <input class="box" type='eventName' name="eventID"><br><br>
      </div>
    <div class="title">Overlay Message:</div>
      <div class="input">
        <textarea  class="box" name="overlay" rows="5"></textarea><br><br>
      </div>
    <div class="title">After Event Email<br>(Donation and Sharable Facebook links included):</div>
      <div class="input">
        <textarea class="box" name="email" rows="5"></textarea><br><br>
      </div>
    <div id="jobs">
        <input id="index" name="index" value="0" class="index"></input>
        <div id="newJob0"></div>
    </div>
    <div class="button">
      <button class="buttonText" type="button" onclick="addJob()">Add Job</button><br>
      <button class="buttonText" type="submit">Submit</button>
    </div>
  </form>
  <div id="qr">
  </div>
</html>
