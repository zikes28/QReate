<html>
<link rel="stylesheet" href="update3.css">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
<script src="code5.js"></script>
<script src="qrcode.min.js"></script>
<div class="events">
  <?php
    $conn = new mysqli("127.0.0.1", "root", "", "FeedingSouthFlorida");
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }
    $sql = "SELECT Event_ID FROM vevents";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
      echo("<div class='jobTitle'>Events:</div>");
      while($row = $result->fetch_assoc()) {
        echo("<a class='jobDesc2' href=update.php?event=".$row["Event_ID"].">".$row["Event_ID"]."</a><br>");
      }
    }
    ?>
    <a class='jobDesc2' href=index.php>New Event</a>
</div>
<div class="main">
  <div class="mainEvent">View Event</div>
    <?php
    if (isset($_GET['event'])){
      $event = $_GET['event'];
      $sql = "SELECT Event_ID, Volunteer_Count, Overlay_Message, Email_Message FROM vevents WHERE Event_ID='$event'";
      $result = $conn->query($sql);
      if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
          $eventID = $row["Event_ID"];
          $count = $row["Volunteer_Count"];
          $overlay = $row["Overlay_Message"];
          $email = $row["Email_Message"];
          echo(
            "<div class='title'>Event Name:</div>
            <input class='box' type='eventName' name='eventID' value=".$eventID.">
            <div class='title'>Overlay Message:</div>
            <textarea class='box' name='overlay' rows='5'>".$overlay."</textarea><br>
            <div class='title'>After Event Email<br>(Donation and Facebook links included):</div>
            <textarea class='box' name='email' rows='5'>".$email."</textarea><br>
            <button type='button' onclick='updateSummary()' class='buttonText'>Update Summary</button>
            <button class='buttonText' type='button' onclick='removeEvent()'>Remove Event</button>"
          );
        }
      }
    }
   ?>
  <br><br>
  <form method="post" action="insert.php">
    <?php
      if (isset($_GET['event'])){
        $event = $_GET['event'];
        $sql = "SELECT Job_ID, Job_Name, Job_Desc, Job_Limit, Job_Limit_Status, Event_ID FROM jobs WHERE Event_ID='$event'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
          $i = 0;
          while($row = $result->fetch_assoc()) {
            $jobID = $row["Job_ID"];
            $jobDesc = $row["Job_Desc"];
            $jobName = $row["Job_Name"];
            $jobLimit = $row["Job_Limit"];
            $i++;
            echo("<div class='title'>Job Title</div>
            <input class='box' type='text' name='jobTitle".$i."' value=".$jobName.">
            <br><div class='title'>Job Description</div>
            <textarea class='box' name='jobDesc".$i."' rows='5'>".$jobDesc."</textarea>
            <br><div class='title'>Number of Participants</div>
            <input class='box' type='number' name='jobNum".$i."' value=".$jobLimit."><br>
            <button class='buttonText' type='button' onclick='updateJob(".$i.")'>Update Job</button>
            <button class='buttonText' type='button' onclick='removeJobFromDatabase(".$i.")'>Remove Job</button>");
          }
          echo("</form>
            <div id='newJob0'></div>
            <br><button class='buttonText' type='button' onclick='addJob()'>Add New Job</button><br>
            <button class='buttonText' type='submit'>Submit New Jobs</button><br><br>");
        }
      }
    ?>
  <div id="qr" class="qr">
  </div>
  <div id="link">
  </div>
  <?php
  if (isset($_GET['event'])){
    echo("<script>generateQR('".$_GET['event']."');</script>
    <button type='button' onclick=emailList('".$_GET['event']."') class='buttonText'>Send Thank You Email</button>");
  }
  ?>
</div>
</body>
</html>
