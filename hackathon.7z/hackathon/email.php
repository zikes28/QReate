<?php
require_once('PHPMailer/src/PHPMailer.php');
$mail = new PHPMailer();
$mail->isSMTP();
$mail->SMTPAuth = true;
$mail->SMTPSecure = 'ssl';
$mail->Host = 'smtp.gmail.com';
$mail->Port = '465';
$mail->isHTML();
$mail->Username = 'zrocks3333@gmail.com';
$mail->Password = 'popeYe123228';
$mail->Subject = 'Thank You!';
$mail->Body = 'Thanks so much for attending!';
$mail->AddAddress('zrocks3333@gmail.com');

$mail->Send();
?>
