function hideOverlay() {
  document.getElementById("overlay").style.display = "none";
}
function emailList(x){
  var eventID = x;
  $.ajax({
      type : "POST",
      url  : "email.php",
      data : {eventID : eventID},
      success: function(res){
        alert(res);
      }
  });
}
function newEvent() {
  confirm("Create a new event?");
}
var i = 0;
function addJob() {
  var i2 = i + 1;
  document.getElementById('newJob'+i).innerHTML += "<div id='job"+i+"' class='job'><div class='title'>New Job Title</div><div class='input'><input type='text' class='box' name='jobTitle"+i+"'></div><div class='title'>New Job Description</div><div class='input'><textarea class='box' name='jobDesc"+i+"' rows='5'></textarea></div><div class='title'>Number of Participants</div><div class='input'><input class='box' type='number' name='jobNum"+i+"'></div><button type='button' class='buttonText' onclick='removeJob("+i+")'>Remove</button><br><br><div id=newJob"+i2+"></div>";
  i++;
  document.getElementById('index').value = i;
}
function removeJob(i3) {
  document.getElementById("job"+i3).remove();
  i = i-1;
  document.getElementById('index').value = i;
}
function generateQR(x) {
  document.getElementById('qr').innerHTML = "<div id='qrcode'></div>";
  var qrData = document.getElementById('qrData');
  var qrcode = new QRCode(document.getElementById('qrcode'));
  qrcode.makeCode("http://localhost/hackathon/userh.php?event="+x);
  document.getElementById('link').innerHTML = ("<a href='http://localhost/hackathon/userh.php?event="+x+"'>link</a>");
}
function areYouSure(x){
  if (document.getElementById('firstName').value == "" || document.getElementById('lastName').value == "" || document.getElementById('email').value == ""){
    alert("please fill out form");
  }
  else {
    var con = confirm("Choose this Job?");
    if(con == true){
      var jobID = x;
      var firstName = document.getElementById("firstName").value;
      var lastName = document.getElementById("lastName").value;
      var email = document.getElementById("email").value;
      $.ajax({
          type : "POST",
          url  : "volunteer.php",
          data : {jobID : jobID, firstName : firstName, lastName : lastName, email : email},
          success: function(res){
            location.replace("http://localhost/hackathon/description.php?jobID="+jobID);
          }
      });
      }
  }
}
