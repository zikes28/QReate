<?php
$conn = new mysqli("127.0.0.1", "root", "", "FeedingSouthFlorida");
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$eventId = $_POST['eventID'];
$overlay = $_POST['overlay'];
$email = $_POST['email'];
$sql = "INSERT INTO vevents (Event_ID, Volunteer_Count, Overlay_Message, Email_Message) VALUES ('$eventId', '0', '$overlay', '$email')";
if ($conn->query($sql) === TRUE) {
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$index = $_POST['index'];

if ($index > 0){
  for ($x = 0; $x < $index; $x++) {
    $jobTitle = $_POST['jobTitle'.$x];
    $jobDesc = $_POST['jobDesc'.$x];
    $jobNum = $_POST['jobNum'.$x];
    $sql = "INSERT INTO jobs (Job_Name, Job_Desc, Event_ID, Job_Limit, Job_Limit_Status) VALUES ('$jobTitle', '$jobDesc', '$eventId','$jobNum','0')";
    if ($conn->query($sql) === TRUE) {
    } else {
      echo "Error: " . $sql . "<br>" . $conn->error;
    }
  }
}

$conn->close();
echo ("<script>window.open('http://localhost/hackathon/update.php?event=".$eventId."')</script>");
echo ("<script>location.replace('http://localhost/hackathon/userh.php?event=".$eventId."')</script>");
echo ("<script></script>");
 ?>
