<?php


?>


<html>

<head>
  <!Doctype html>
  <title>Login</title>
</head>

<header>

</header>

<body>
  <div id = "frm_Container">
    <form action = "process.php" method = "POST">
      <p>
        <label>Username:</label>
        <input type="text" id = "user" name="username"/>
      </p>
      <p>
        <label>Password:</label>
        <input type = "text" id="password" name = "password" />
      </p>
      <input type = "submit" id="btn" value = "Login"/>
    </form>
  </div>

</body>
</html>
