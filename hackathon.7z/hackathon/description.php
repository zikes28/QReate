<link rel="stylesheet" href="update2.css">
<?php
$conn = new mysqli("127.0.0.1", "root", "", "FeedingSouthFlorida");
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
if (isset($_GET['jobID'])){
  $jobID = $_GET['jobID'];
  $sql = "SELECT Job_Name, Job_Desc, Event_ID FROM jobs WHERE Job_ID='$jobID'";
  $result = $conn->query($sql);
  if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo("<div class='job'>you chose:</div><div class='jobName'>".$row["Job_Name"]."</div><div class='jobDesc2'>".$row["Job_Desc"]."</div>");
    }
  }
}
 ?>
